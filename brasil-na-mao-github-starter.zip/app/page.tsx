"use client";

import { useMemo, useState } from "react";
import { Building2, ChevronDown, CircleHelp, Expand, MapPin, Minus, Newspaper, Plus, Search, Store, Trophy, UserRound, X, Megaphone, BriefcaseBusiness, ShieldCheck } from "lucide-react";
import { demoParticipants, states } from "@/lib/brazil";

type Panel = "profissao" | "loja" | "anunciar" | "ranking" | "dados" | "privacidade" | "ajuda" | null;
type Tab = "mapa" | "jornal";

export default function Home() {
  const [tab, setTab] = useState<Tab>("mapa");
  const [query, setQuery] = useState("");
  const [panel, setPanel] = useState<Panel>(null);
  const [zoom, setZoom] = useState(1);
  const [selected, setSelected] = useState<string | null>(null);
  const [notice, setNotice] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [adName, setAdName] = useState("");
  const [adCity, setAdCity] = useState("");
  const [profession, setProfession] = useState("Empresário");

  const foundParticipant = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return null;
    return demoParticipants.find(p => p.handle.toLowerCase() === (q.startsWith("@") ? q : `@${q}`) || p.city.toLowerCase() === q || p.state.toLowerCase() === q) ?? null;
  }, [query]);

  function search() {
    const q = query.trim().toLowerCase();
    if (!q) { setNotice("Digite um @ do Instagram, cidade ou estado."); return; }
    if (foundParticipant) {
      setSelected(foundParticipant.handle);
      setNotice(`Exemplo demonstrativo: ${foundParticipant.city} (${foundParticipant.state}). Conecte o banco de dados para buscar registros reais.`);
      return;
    }
    const state = states.find(s => s.name.toLowerCase() === q || s.uf.toLowerCase() === q);
    if (state) {
      setNotice(`${state.name} (${state.uf}) localizado no mapa ilustrativo.`);
      setSelected(state.uf);
      return;
    }
    setNotice("Nenhum registro encontrado nos dados locais de demonstração. A busca real será habilitada após conectar o banco de dados.");
  }

  function copyPix() {
    const pix = "00020126960014BR.GOV.BCB.PIX0136a07222c0-64b4-4131-aff2-2ec8b0464f0c0234MM ads (envie o comprovante na dm)520400005303986540512.595802BR5925Samuel Csizmadia Marinhei6009SAO PAULO62140510RBpMLLMMKN63047B4D";
    void navigator.clipboard.writeText(pix).then(() => setNotice("Código PIX copiado. Envie o comprovante por Direct para @brasilnamao.bm.")).catch(() => setNotice("Copie o código PIX disponível no painel administrativo e envie o comprovante por Direct."));
  }

  return (
    <main className="relative min-h-screen overflow-hidden">
      <div className="fixed inset-0 z-0 map-scene">
        <div className="absolute inset-0 opacity-60" style={{ backgroundImage: "radial-gradient(ellipse at 20% 30%, white 0 2px, transparent 4px), radial-gradient(ellipse at 72% 64%, white 0 3px, transparent 5px)", backgroundSize: "210px 160px, 280px 230px" }} />
        <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
          <div className="relative transition-transform duration-300" style={{ transform: `scale(${zoom})`, width: "min(78vw, 900px)", height: "min(85vh, 800px)" }}>
            <svg viewBox="0 0 100 110" className="h-full w-full drop-shadow-[0_8px_2px_rgba(24,34,46,0.2)]" role="img" aria-label="Mapa ilustrativo do Brasil">
              <path d="M35 5 L49 7 L55 13 L67 14 L70 22 L80 24 L82 31 L92 33 L95 41 L89 46 L94 51 L88 57 L90 64 L83 68 L80 77 L74 81 L73 90 L66 94 L64 103 L58 108 L54 101 L49 97 L45 89 L39 84 L36 75 L29 71 L30 63 L22 58 L23 50 L16 45 L19 36 L25 29 L26 20 L32 15 Z" fill="#a6ca83" stroke="#fff6c6" strokeWidth="1.5" />
              <path d="M31 19 L44 16 L48 25 L43 32 L32 31 Z M50 15 L62 18 L65 27 L57 32 L48 26 Z M25 35 L38 33 L43 42 L35 50 L24 45 Z M43 34 L57 34 L60 46 L48 52 L39 44 Z M61 30 L74 28 L79 38 L70 45 L60 42 Z M47 54 L60 49 L70 54 L67 66 L55 69 L48 63 Z M34 53 L45 50 L48 62 L42 72 L35 66 Z M69 47 L82 43 L86 52 L78 60 L69 57 Z M55 72 L68 68 L73 77 L66 86 L57 84 Z M43 76 L54 72 L57 84 L50 93 L44 86 Z M59 88 L66 87 L63 98 L58 104 L55 97 Z" fill="#78ad68" stroke="#d9e7a0" strokeWidth=".8" />
              <g fill="none" stroke="#d9edb2" strokeWidth=".8" opacity=".9">
                <path d="M27 24 Q45 35 61 22 T83 39" /><path d="M21 42 Q40 46 54 38 T86 49" /><path d="M31 59 Q47 56 63 63 T80 59" /><path d="M38 75 Q52 78 69 73" /><path d="M48 88 Q57 87 65 94" />
              </g>
            </svg>
            {states.filter(s => s.y < 100).map(s => (
              <button key={s.uf} onClick={() => { setSelected(s.uf); setNotice(`${s.name}: território selecionado no mapa ilustrativo.`); }} className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-[#18222e] px-1.5 py-0.5 text-[10px] font-black shadow-[0_2px_0_#18222e] sm:text-xs ${selected === s.uf ? "bg-orange-400" : "bg-[#ffd438]"}`} style={{ left: `${s.x}%`, top: `${s.y}%` }} title={s.name}>{s.uf}</button>
            ))}
            {demoParticipants.map(p => (
              <button key={p.handle} onClick={() => { setSelected(p.handle); setNotice(`${p.handle} — exemplo demonstrativo. Conecte o banco para exibir participantes reais.`); }} className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-[#18222e] bg-white px-2 py-1 text-[10px] font-black shadow-[0_2px_0_#18222e] sm:text-xs" style={{ left: `${p.x}%`, top: `${p.y}%` }} title={p.handle}>{p.handle}</button>
            ))}
          </div>
        </div>
      </div>

      <header className="pointer-events-none fixed inset-x-0 top-0 z-20 flex flex-col items-center px-3 pt-3">
        <div className="outlined text-center text-3xl font-black tracking-tight sm:text-5xl">veja sua <span style={{ color: "#ffd438" }}>cidade</span></div>
        <form className="pointer-events-auto mt-2 flex w-full max-w-[500px] gap-2" onSubmit={e => { e.preventDefault(); search(); }}>
          <div className="flex min-w-0 flex-1 items-center gap-2 rounded-full border-[3px] border-[#18222e] bg-white px-4 shadow-[0_5px_0_rgba(24,34,46,.8)]">
            <Search size={20} className="shrink-0 text-slate-500" />
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="@ do Instagram, cidade ou estado" className="min-w-0 w-full bg-transparent py-3 font-bold outline-none placeholder:text-slate-400" aria-label="Buscar participante, cidade ou estado" />
          </div>
          <button className="game-button bg-[#ffd438] px-5 py-2">achar</button>
        </form>
        <button onClick={() => setPanel("loja")} className="pointer-events-auto game-button mt-3 bg-[#ffd438] px-5 py-2 text-sm">🏪 registrar meu negócio na minha cidade</button>
      </header>

      <div className="fixed right-3 top-4 z-20 flex flex-col gap-3 sm:right-5 sm:top-1/2 sm:-translate-y-1/2">
        <button onClick={() => setPanel("ajuda")} aria-label="Ajuda" className="game-button flex h-11 w-11 items-center justify-center bg-[#ffd438]"><CircleHelp /></button>
        <div className="hidden sm:block sm:h-24" />
        <button onClick={() => setZoom(z => Math.min(1.7, z + .1))} aria-label="Aumentar zoom" className="game-button flex h-11 w-11 items-center justify-center bg-white"><Plus /></button>
        <button onClick={() => setZoom(z => Math.max(.65, z - .1))} aria-label="Diminuir zoom" className="game-button flex h-11 w-11 items-center justify-center bg-white"><Minus /></button>
        <button onClick={() => { setZoom(1); setSelected(null); }} aria-label="Recentralizar mapa" className="game-button flex h-11 w-11 items-center justify-center bg-white"><Expand /></button>
      </div>

      <div className="fixed bottom-4 left-3 z-20 max-w-[calc(100vw-24px)] sm:left-5">
        <div className="outlined mb-3 text-sm font-black sm:text-xl">Brasil na Mão · mapa ilustrativo</div>
        <div className="flex flex-wrap gap-2">
          <button onClick={() => setPanel("ranking")} className="game-button bg-[#ffd438] px-4 py-2 text-sm">🏆 ranking</button>
          <button onClick={() => setPanel("profissao")} className="game-button bg-white px-4 py-2 text-sm">profissão</button>
          <button onClick={() => setPanel("loja")} className="game-button bg-white px-4 py-2 text-sm">minha loja</button>
          <button onClick={() => setPanel("anunciar")} className="game-button bg-white px-4 py-2 text-sm">anunciar</button>
          <button onClick={() => setPanel("dados")} className="game-button bg-white px-4 py-2 text-sm">dados</button>
          <button onClick={() => setPanel("privacidade")} className="game-button bg-white px-4 py-2 text-sm">privacidade</button>
        </div>
        <div className="mt-3 flex gap-2">
          <button onClick={() => setTab("mapa")} className={`game-button flex items-center gap-2 px-4 py-2 text-sm ${tab === "mapa" ? "bg-[#ffd438]" : "bg-white"}`}><MapPin size={16}/> Mapa</button>
          <button onClick={() => setTab("jornal")} className={`game-button flex items-center gap-2 px-4 py-2 text-sm ${tab === "jornal" ? "bg-[#ffd438]" : "bg-white"}`}><Newspaper size={16}/> Jornal BM</button>
        </div>
      </div>

      {notice && <div role="status" className="fixed bottom-36 left-3 z-30 max-w-[min(90vw,520px)] rounded-xl border-2 border-[#18222e] bg-white p-3 text-sm font-bold shadow-lg sm:left-5">{notice}<button className="ml-3 inline-flex" aria-label="Fechar aviso" onClick={() => setNotice("")}><X size={16}/></button></div>}

      {tab === "jornal" && (
        <div className="fixed inset-0 z-40 overflow-y-auto bg-[#a9ddf1]/95 p-4 pt-20 backdrop-blur-sm sm:p-10 sm:pt-24">
          <section className="mx-auto max-w-3xl panel-card p-5 sm:p-8">
            <div className="flex items-center gap-3"><Newspaper size={34}/><div><h1 className="text-3xl font-black">Jornal BM</h1><p className="text-sm font-semibold text-slate-600">Brasil na Mão</p></div></div>
            <div className="mt-5 rounded-2xl bg-[#ffd438] p-4"><h2 className="text-xl font-black">As novidades do nosso mundo</h2><p className="mt-1 text-sm">Edição semanal prevista para segunda-feira, às 14h (horário de Brasília).</p></div>
            <p className="mt-5 text-sm leading-6">As notícias reais da comunidade aparecerão aqui quando o banco de dados e o painel editorial estiverem conectados. Nenhuma notícia fictícia será apresentada como publicada.</p>
            <button onClick={() => setTab("mapa")} className="game-button mt-5 bg-white px-5 py-3">Voltar ao mapa</button>
          </section>
        </div>
      )}

      {panel && <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/35 p-3 sm:items-center" onClick={() => setPanel(null)}>
        <section className="panel-card max-h-[85vh] w-full max-w-lg overflow-y-auto p-5 sm:p-6" onClick={e => e.stopPropagation()}>
          <div className="flex items-start justify-between gap-3"><div>
            <h2 className="text-2xl font-black">{({ profissao: "Profissão", loja: "Minha Loja", anunciar: "BM Ads · Anunciar", ranking: "Ranking", dados: "Dados do mapa", privacidade: "Privacidade", ajuda: "Como funciona" } as const)[panel]}</h2>
            <p className="mt-1 text-sm text-slate-600">Brasil na Mão</p>
          </div><button onClick={() => setPanel(null)} className="rounded-full border-2 border-slate-800 p-2" aria-label="Fechar painel"><X size={18}/></button></div>

          {panel === "profissao" && <div className="mt-5 space-y-4">
            <label className="block text-sm font-bold">Escolha uma trajetória
              <select value={profession} onChange={e => setProfession(e.target.value)} className="mt-2 w-full rounded-xl border-2 border-slate-800 bg-white p-3">
                {["Cidadão","Empresário","Líder de bairro","Vereador","Prefeito","Deputado estadual","Deputado federal","Senador","Ministro","Vice-presidente","Presidente"].map(x => <option key={x}>{x}</option>)}
              </select>
            </label>
            <div className="rounded-2xl bg-sky-100 p-4"><p className="font-black">Objetivo selecionado: {profession}</p><p className="mt-1 text-sm">O progresso real aparecerá quando o banco de dados e as regras de pontuação estiverem configurados.</p><div className="mt-3 h-3 overflow-hidden rounded-full bg-white"><div className="h-full w-0 rounded-full bg-emerald-500"/></div><p className="mt-2 text-xs text-slate-600">Não há progresso real conectado ainda.</p></div>
            <p className="text-xs text-slate-500">Cargos políticos são conquistas fictícias dentro da plataforma, não cargos públicos reais.</p>
          </div>}

          {panel === "loja" && <form className="mt-5 space-y-3" onSubmit={e => { e.preventDefault(); setNotice("Solicitação de loja demonstrativa preenchida. Conecte o banco de dados para salvar e publicar."); setPanel(null); }}>
            <label className="block text-sm font-bold">Nome do negócio<input value={businessName} onChange={e => setBusinessName(e.target.value)} required placeholder="Ex.: Minha Loja" className="mt-1 w-full rounded-xl border-2 border-slate-800 p-3 font-normal"/></label>
            <label className="block text-sm font-bold">Cidade e estado<input value={adCity} onChange={e => setAdCity(e.target.value)} required placeholder="Ex.: Itupeva, SP" className="mt-1 w-full rounded-xl border-2 border-slate-800 p-3 font-normal"/></label>
            <button className="game-button w-full bg-[#ffd438] p-3">Solicitar registro da loja</button>
            <p className="text-xs text-slate-500">Demonstração: conectar o banco de dados para persistir solicitações.</p>
          </form>}

          {panel === "anunciar" && <div className="mt-5 space-y-4">
            <div className="rounded-2xl bg-[#fff0ae] p-4"><p className="text-2xl font-black">R$ 12,99</p><p className="font-bold">7 dias de anúncio</p><p className="mt-1 text-sm">Seu anúncio poderá aparecer em outdoors virtuais da cidade escolhida após aprovação.</p></div>
            <label className="block text-sm font-bold">Nome da campanha<input value={adName} onChange={e => setAdName(e.target.value)} placeholder="Nome da sua marca" className="mt-1 w-full rounded-xl border-2 border-slate-800 p-3 font-normal"/></label>
            <label className="block text-sm font-bold">Cidade e estado<input value={adCity} onChange={e => setAdCity(e.target.value)} placeholder="Ex.: Itupeva, SP" className="mt-1 w-full rounded-xl border-2 border-slate-800 p-3 font-normal"/></label>
            <p className="text-sm">Pagamento e comprovante são tratados exclusivamente pelo Direct.</p>
            <button onClick={copyPix} className="game-button w-full bg-[#ffd438] p-3">Copiar código PIX</button>
            <a href="https://www.instagram.com/brasilnamao.bm/" target="_blank" rel="noreferrer" className="game-button flex w-full items-center justify-center bg-white p-3">Enviar solicitação pelo Direct @brasilnamao.bm</a>
            <p className="text-xs leading-5 text-slate-500">A campanha não será publicada automaticamente. Envie o comprovante por DM e aguarde a confirmação do pagamento e a aprovação da imagem. O código PIX precisa ser validado antes da publicação comercial.</p>
          </div>}

          {panel === "ranking" && <div className="mt-5 space-y-3"><p className="text-sm">Ranking demonstrativo. Os participantes reais serão exibidos após a conexão do banco de dados.</p>{demoParticipants.map((p, i) => <div key={p.handle} className="flex items-center justify-between rounded-xl bg-sky-50 p-3"><span className="font-bold">{i+1}. {p.handle}</span><span className="font-black">{p.points} pts*</span></div>)}</div>}
          {panel === "dados" && <div className="mt-5 space-y-3 text-sm"><p><b>Estados no mapa ilustrativo:</b> {states.length}</p><p><b>Participantes de demonstração:</b> {demoParticipants.length}</p><p>Esses números representam apenas dados de demonstração, não estatísticas reais do Brasil na Mão.</p></div>}
          {panel === "privacidade" && <div className="mt-5 space-y-3 text-sm leading-6"><p>O projeto deve coletar somente os dados necessários à operação. Não associe a cidade mencionada em um comentário à residência real de seu autor sem confirmação.</p><p>Antes de produção, publicar uma política de privacidade completa, definir prazos de retenção e implementar solicitações de correção e exclusão.</p></div>}
          {panel === "ajuda" && <div className="mt-5 space-y-3 text-sm leading-6"><p>Pesquise um @ do Instagram, uma cidade ou um estado para localizar registros.</p><p>Use os controles laterais para ampliar, reduzir ou recentralizar o mapa.</p><p>Esta versão é uma interface inicial. A conexão com banco de dados e a API oficial do Instagram ainda precisa ser configurada.</p></div>}
        </section>
      </div>}

      <footer className="pointer-events-none fixed bottom-1 right-2 z-10 text-[10px] text-slate-700/70">Versão inicial · mapa ilustrativo</footer>
    </main>
  );
}
