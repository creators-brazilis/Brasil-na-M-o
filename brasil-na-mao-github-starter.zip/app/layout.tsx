import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Brasil na Mão",
  description: "Explore o Brasil, encontre cidades e acompanhe o crescimento da comunidade.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
