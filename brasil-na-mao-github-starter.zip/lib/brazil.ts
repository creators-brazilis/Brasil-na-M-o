export type BrazilianState = { name: string; uf: string; x: number; y: number };

export const states: BrazilianState[] = [
  { name: "Acre", uf: "AC", x: 24, y: 36 }, { name: "Amazonas", uf: "AM", x: 38, y: 23 },
  { name: "Roraima", uf: "RR", x: 48, y: 10 }, { name: "Rondônia", uf: "RO", x: 39, y: 43 },
  { name: "Pará", uf: "PA", x: 57, y: 29 }, { name: "Amapá", uf: "AP", x: 66, y: 17 },
  { name: "Tocantins", uf: "TO", x: 60, y: 45 }, { name: "Maranhão", uf: "MA", x: 72, y: 36 },
  { name: "Piauí", uf: "PI", x: 79, y: 43 }, { name: "Ceará", uf: "CE", x: 87, y: 36 },
  { name: "Rio Grande do Norte", uf: "RN", x: 94, y: 40 }, { name: "Paraíba", uf: "PB", x: 95, y: 46 },
  { name: "Pernambuco", uf: "PE", x: 91, y: 52 }, { name: "Alagoas", uf: "AL", x: 96, y: 55 },
  { name: "Sergipe", uf: "SE", x: 94, y: 60 }, { name: "Bahia", uf: "BA", x: 80, y: 59 },
  { name: "Mato Grosso", uf: "MT", x: 53, y: 55 }, { name: "Mato Grosso do Sul", uf: "MS", x: 52, y: 72 },
  { name: "Goiás", uf: "GO", x: 64, y: 63 }, { name: "Distrito Federal", uf: "DF", x: 69, y: 61 },
  { name: "Minas Gerais", uf: "MG", x: 77, y: 70 }, { name: "Espírito Santo", uf: "ES", x: 88, y: 75 },
  { name: "Rio de Janeiro", uf: "RJ", x: 85, y: 81 }, { name: "São Paulo", uf: "SP", x: 72, y: 81 },
  { name: "Paraná", uf: "PR", x: 67, y: 88 }, { name: "Santa Catarina", uf: "SC", x: 71, y: 94 },
  { name: "Rio Grande do Sul", uf: "RS", x: 67, y: 101 },
];

export const demoParticipants = [
  { handle: "@exemplo.sp", city: "São Paulo", state: "SP", points: 70, x: 72, y: 81, building: "Casa moderna" },
  { handle: "@exemplo.am", city: "Manaus", state: "AM", points: 42, x: 38, y: 23, building: "Casa ampliada" },
  { handle: "@exemplo.ba", city: "Salvador", state: "BA", points: 28, x: 80, y: 59, building: "Casa simples" },
];
