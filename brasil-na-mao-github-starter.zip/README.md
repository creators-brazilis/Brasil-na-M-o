# Brasil na Mão

Aplicação inicial em Next.js para o projeto Brasil na Mão. Inclui uma interface ilustrativa de mapa, busca local demonstrativa, painel de profissões, Minha Loja, BM Ads e Jornal BM.

> Importante: os registros incluídos são exemplos locais, não participantes reais. A integração com o Instagram e o banco de dados ainda não está ativa nesta versão.

## Requisitos

- Node.js 20.9 ou superior
- npm
- Conta GitHub
- Conta Vercel para implantação
- Banco de dados opcional para iniciar a interface; necessário para persistência real

## Executar localmente

```bash
npm install
cp .env.example .env.local
npm run dev
```

Abra `http://localhost:3000`.

## Publicar no GitHub e Vercel

1. Crie um repositório vazio no GitHub.
2. Envie os arquivos deste projeto ao repositório.
3. Entre na Vercel e importe o repositório.
4. Use as configurações padrão de Next.js e publique.
5. Adicione as variáveis de ambiente somente quando configurar serviços externos.

## Configurar o banco de dados

O projeto ainda não persiste dados. Para produção, configure Supabase ou outro banco de dados gerenciado. Crie políticas de acesso, tabelas, índices e validação no servidor antes de armazenar participantes ou anúncios reais.

## Instagram

A sincronização real exige uma conta profissional compatível, um aplicativo Meta, permissões aprovadas, tokens armazenados no servidor, URL pública e webhooks verificados. A API não oferece acesso irrestrito a todos os comentários de qualquer conta. Nunca coloque segredos em variáveis `NEXT_PUBLIC_*`.

## BM Ads

O protótipo mostra o fluxo de R$ 12,99 por 7 dias, com contato pelo Direct `@brasilnamao.bm`. O pagamento e a aprovação são manuais; nenhum pagamento é confirmado automaticamente.

**Valide o código PIX com o recebedor antes de usá-lo comercialmente.** O código informado foi incluído no protótipo para copiar, mas não foi validado pelo banco.

## Antes de produção

- Remover ou substituir os dados demonstrativos.
- Implementar autenticação administrativa segura.
- Criar o banco de dados e políticas de acesso.
- Configurar upload seguro de imagens.
- Implementar integração oficial com Instagram e webhooks.
- Implementar atribuição de pontos no servidor com prevenção de duplicações.
- Criar política de privacidade e termos de uso.
- Configurar agendamento real do Jornal BM.
- Testar acessibilidade, desempenho e responsividade.
